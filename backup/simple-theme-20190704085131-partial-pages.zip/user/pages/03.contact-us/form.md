---
title: 'Contact Us'
visible: true
twitterenable: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
musicalbumenabled: false
productenabled: false
product:
    ratingValue: 2.5
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
facebookenable: true
form:
    classes: 'row has-validator'
    name: contact
    validation_fail: test
    fields:
        first_name:
            outerclasses: 'col-12 col-md-6'
            name: 'First Name'
            label: 'First Name'
            type: text
            validate:
                required: true
        last_name:
            outerclasses: 'col-12 col-md-6'
            name: 'Last Name'
            label: 'Last Name'
            type: text
            validate:
                required: true
        email:
            outerclasses: col-12
            label: Email
            type: email
            validate:
                required: true
        message:
            outerclasses: col-12
            label: Message
            type: textarea
            validate:
                required: true
    buttons:
        submit:
            outerclasses: col-12
            type: submit
            value: Submit
    process:
        save:
            fileprefix: contact-
            dateformat: Ymd-His-u
            extension: txt
            body: '{% include ''forms/data.txt.twig'' %}'
        email:
            subject: '[Site Contact Form] {{ form.value.name|e }}'
            body: '{% include ''forms/data.html.twig'' %}'
        message: 'Thank you for getting in touch!'
        display: /thank-you
---

