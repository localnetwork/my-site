---
title: 'Get A Quote'
routable: false
visible: false
twitterenable: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
musicalbumenabled: false
productenabled: false
product:
    ratingValue: 2.5
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
facebookenable: true
---

<p>Do you need custom cable assembly, wire harnessing, or electro-mechanical assembly services? Are you looking for engineering support, too? SHINE is ready to help.</p>