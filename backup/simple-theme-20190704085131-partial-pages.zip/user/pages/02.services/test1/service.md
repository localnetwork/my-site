---
title: 'Custom Cable Assembly'
featured: true
shortdesc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
visible: true
featured_image:
    user/pages/02.services/test/cable-assembly-2.jpg:
        name: cable-assembly-2.jpg
        type: image/jpeg
        size: 15439
        path: user/pages/02.services/test/cable-assembly-2.jpg
slider:
    user/pages/02.services/test/background-services.jpg:
        name: background-services.jpg
        type: image/jpeg
        size: 293890
        path: user/pages/02.services/test/background-services.jpg
    user/pages/02.services/test/halcyon-banner_1.jpg:
        name: halcyon-banner_1.jpg
        type: image/jpeg
        size: 310475
        path: user/pages/02.services/test/halcyon-banner_1.jpg
summary: '<p>summary</p>'
---

<p>body</p>