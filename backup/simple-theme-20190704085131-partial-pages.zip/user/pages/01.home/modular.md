---
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _slider
            - _text
            - _services
sitemap:
    priority: !!float 1
visible: true
googledesc: 'Boilerplate created by Halcyon Web Design'
twitterenable: true
twittercardoptions: summary
twittershareimg: /home/_slider/camogli-4166255_1920.jpg
twitterdescription: 'Test only'
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
musicalbumenabled: false
productenabled: false
product:
    ratingValue: 2.5
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
facebookenable: true
facebookdesc: 'This is a test'
facebookimg: /home/_slider/light-4297386_1920.jpg
---

